package uz.rehber.cevrimdisi;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StatFs;
import android.content.pm.ActivityInfo;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.io.FilterInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {

    static final String ADRES = "https://appassets.androidplatform.net/assets/www/index.html";
    static final int REQ_DOSYA = 1, REQ_KLASOR = 2, REQ_KONUM = 3, REQ_KAYDET = 4, REQ_VIDEO = 5, REQ_MIKROFON = 6;
    PermissionRequest bekleyenIzin;
    static final String[] VIDEO_UZ = {".mp4", ".webm", ".m4v", ".mkv", ".3gp", ".mov", ".ogv"};
    FrameLayout kok;
    View tamEkran;
    WebChromeClient.CustomViewCallback tamEkranCb;

    WebView web;
    ValueCallback<Uri[]> dosyaCb;
    GeolocationPermissions.Callback geoCb;
    String geoOrigin;
    String bekleyenIcerik;
    volatile boolean kopyalaniyor = false;

    File rehberKlasoru() {
        File d = new File(getFilesDir(), "rehber");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    @Override
    protected void onCreate(Bundle kayit) {
        super.onCreate(kayit);
        web = new WebView(this);
        kok = new FrameLayout(this);
        kok.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(kok);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setTextZoom(100);

        final WebViewAssetLoader yukleyici = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/rehber/", new IcerikYolu(rehberKlasoru()))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost()) && u.getPath() != null && u.getPath().startsWith("/rehber/")) {
                    return rehberDosya(u.getPath().substring(8), r.getRequestHeaders());
                }
                return yukleyici.shouldInterceptRequest(u);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                // tel:, geo:, http(s) dış bağlantılar -> telefonun kendi uygulamaları
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Bunu açacak uygulama bulunamadı", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (tamEkran != null) { cb.onCustomViewHidden(); return; }
                tamEkran = view;
                tamEkranCb = cb;
                kok.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                web.setVisibility(View.GONE);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }

            @Override
            public void onHideCustomView() {
                tamEkranKapat();
            }

            // Kur'an bölümündeki mikrofonla ayet arama için
            @Override
            public void onPermissionRequest(PermissionRequest istek) {
                runOnUiThread(() -> {
                    boolean ses = false;
                    for (String r : istek.getResources())
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) ses = true;
                    if (!ses) { istek.deny(); return; }
                    if (Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        istek.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        bekleyenIzin = istek;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIKROFON);
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (konumIzniVar()) {
                    cb.invoke(origin, true, true);
                } else {
                    geoOrigin = origin;
                    geoCb = cb;
                    if (Build.VERSION.SDK_INT >= 23) {
                        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_KONUM);
                    }
                }
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (dosyaCb != null) dosyaCb.onReceiveValue(null);
                dosyaCb = cb;
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(i, REQ_DOSYA);
                } catch (Exception e) {
                    dosyaCb = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Kopru(), "Android");

        if (kayit != null) web.restoreState(kayit);
        else web.loadUrl(ADRES);
    }

    boolean konumIzniVar() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int kod, String[] izinler, int[] sonuc) {
        super.onRequestPermissionsResult(kod, izinler, sonuc);
        if (kod == REQ_MIKROFON && bekleyenIzin != null) {
            boolean ok = sonuc.length > 0 && sonuc[0] == PackageManager.PERMISSION_GRANTED;
            if (ok) bekleyenIzin.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else bekleyenIzin.deny();
            bekleyenIzin = null;
        }
        if (kod == REQ_KONUM && geoCb != null) {
            geoCb.invoke(geoOrigin, konumIzniVar(), true);
            geoCb = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle b) {
        super.onSaveInstanceState(b);
        web.saveState(b);
    }

    void tamEkranKapat() {
        if (tamEkran == null) return;
        kok.removeView(tamEkran);
        tamEkran = null;
        web.setVisibility(View.VISIBLE);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        if (tamEkranCb != null) tamEkranCb.onCustomViewHidden();
        tamEkranCb = null;
    }

    // /rehber/... dosyalarını sunar; videoda ileri-geri sarabilmek için "Range" isteklerini destekler
    WebResourceResponse rehberDosya(String ic, Map<String, String> basliklar) {
        Map<String, String> h = new HashMap<>();
        h.put("Accept-Ranges", "bytes");
        h.put("Access-Control-Allow-Origin", "*");
        try {
            File kokK = rehberKlasoru();
            File f = new File(kokK, ic);
            if (!f.getCanonicalPath().startsWith(kokK.getCanonicalPath()) || !f.isFile())
                return new WebResourceResponse("text/plain", "utf-8", 404, "Yok", h, null);
            String tur = IcerikYolu.tur(ic);
            String kod = (tur.startsWith("text/") || tur.contains("javascript") || tur.contains("json")) ? "utf-8" : null;
            long uz = f.length();
            String aralik = null;
            if (basliklar != null) for (Map.Entry<String, String> e : basliklar.entrySet())
                if ("range".equalsIgnoreCase(e.getKey())) aralik = e.getValue();
            if (aralik != null && aralik.startsWith("bytes=")) {
                String[] p = aralik.substring(6).split(",")[0].split("-", 2);
                long bas, son;
                if (p[0].trim().isEmpty()) { // son N bayt
                    long n = Long.parseLong(p[1].trim());
                    bas = Math.max(0, uz - n); son = uz - 1;
                } else {
                    bas = Long.parseLong(p[0].trim());
                    son = (p.length > 1 && !p[1].trim().isEmpty()) ? Long.parseLong(p[1].trim()) : uz - 1;
                }
                if (son >= uz) son = uz - 1;
                if (bas > son || bas >= uz) {
                    h.put("Content-Range", "bytes */" + uz);
                    return new WebResourceResponse(tur, kod, 416, "Range Not Satisfiable", h, null);
                }
                FileInputStream in = new FileInputStream(f);
                long atla = bas;
                while (atla > 0) { long a = in.skip(atla); if (a <= 0) break; atla -= a; }
                long boy = son - bas + 1;
                h.put("Content-Range", "bytes " + bas + "-" + son + "/" + uz);
                h.put("Content-Length", String.valueOf(boy));
                return new WebResourceResponse(tur, kod, 206, "Partial Content", h, new SinirliAkis(in, boy));
            }
            h.put("Content-Length", String.valueOf(uz));
            return new WebResourceResponse(tur, kod, 200, "OK", h, new FileInputStream(f));
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Yok", h, null);
        }
    }

    static class SinirliAkis extends FilterInputStream {
        long kalan;
        SinirliAkis(InputStream in, long n) { super(in); kalan = n; }
        @Override public int read() throws IOException {
            if (kalan <= 0) return -1;
            int b = super.read();
            if (b >= 0) kalan--;
            return b;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (kalan <= 0) return -1;
            int n = super.read(b, off, (int) Math.min(len, kalan));
            if (n > 0) kalan -= n;
            return n;
        }
        @Override public int available() throws IOException {
            return (int) Math.min(super.available(), kalan);
        }
    }

    @Override
    public void onBackPressed() {
        if (tamEkran != null) { tamEkranKapat(); return; }
        // Önce uygulamanın içindeki pencereyi/sekmeyi kapatmayı dene
        web.evaluateJavascript("(window.geriTusu&&window.geriTusu())?'1':'0'", deger -> {
            if (deger == null || !deger.contains("1")) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onActivityResult(int kod, int sonuc, Intent veri) {
        super.onActivityResult(kod, sonuc, veri);
        if (kod == REQ_DOSYA) {
            if (dosyaCb != null) {
                Uri u = (sonuc == RESULT_OK && veri != null) ? veri.getData() : null;
                dosyaCb.onReceiveValue(u != null ? new Uri[]{u} : null);
                dosyaCb = null;
            }
        } else if (kod == REQ_KLASOR) {
            if (sonuc == RESULT_OK && veri != null && veri.getData() != null) icerikKopyala(veri.getData());
            else js("window.icerikBitti&&icerikBitti(false,'Klasör seçilmedi.')");
        } else if (kod == REQ_VIDEO) {
            if (sonuc == RESULT_OK && veri != null && veri.getData() != null) videoKopyala(veri.getData());
            else js("window.videoBitti&&videoBitti(false,'Klasör seçilmedi.')");
        } else if (kod == REQ_KAYDET) {
            if (sonuc == RESULT_OK && veri != null && veri.getData() != null && bekleyenIcerik != null) {
                try (OutputStream o = getContentResolver().openOutputStream(veri.getData())) {
                    o.write(bekleyenIcerik.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Yedek kaydedildi", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Kaydedilemedi: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            bekleyenIcerik = null;
        }
    }

    void js(String kod) {
        runOnUiThread(() -> web.evaluateJavascript(kod, null));
    }

    static String jsMetin(String s) {
        return JSONObject.quote(s == null ? "" : s);
    }

    // ------------------------------------------------------------------
    // İçerik paketlerini (harita, wikipedia, kitaplar...) seçilen klasörden
    // uygulamanın içine kopyalar. Kaynak: telefon, hafıza kartı, USB/HDD (OTG).
    // ------------------------------------------------------------------
    void icerikKopyala(Uri agac) {
        if (kopyalaniyor) return;
        kopyalaniyor = true;
        new Thread(() -> {
            long[] sayac = {0, 0, System.currentTimeMillis()}; // dosya, bayt, son bildirim
            try {
                DocumentFile kok = DocumentFile.fromTreeUri(this, agac);
                if (kok == null || !kok.isDirectory()) throw new Exception("Klasör okunamadı");
                File hedefKok = rehberKlasoru();
                int paket = 0;
                // Seçilen klasörün kendisi bir harita klasörüyse
                if (kok.findFile("index.js") != null && kok.findFile("d") != null) {
                    klasorDegistir(kok, new File(hedefKok, "harita"), sayac);
                    paket++;
                } else if (kok.findFile("index.js") != null && kok.findFile("c") != null && kok.findFile("i") != null) {
                    klasorDegistir(kok, new File(hedefKok, guvenliAd(kok.getName() == null ? "wikipedia" : kok.getName())), sayac);
                    paket++;
                } else {
                    for (DocumentFile c : kok.listFiles()) {
                        String ad = c.getName();
                        if (ad == null || ad.startsWith(".")) continue;
                        if (c.isDirectory()) {
                            klasorDegistir(c, new File(hedefKok, guvenliAd(ad)), sayac);
                            paket++;
                        }
                    }
                }
                if (paket == 0) throw new Exception("Bu klasörde içerik paketi bulunamadı (örnek: harita klasörü).");
                js("window.icerikBitti&&icerikBitti(true," + jsMetin(sayac[0] + " dosya kopyalandı") + ")");
            } catch (Exception e) {
                js("window.icerikBitti&&icerikBitti(false," + jsMetin("Hata: " + e.getMessage()) + ")");
            } finally {
                kopyalaniyor = false;
            }
        }).start();
    }

    static boolean videoMu(String ad) {
        String a = ad.toLowerCase();
        for (String u : VIDEO_UZ) if (a.endsWith(u)) return true;
        return false;
    }

    // Seçilen klasördeki videoları (alt klasörler dahil) rehber/videolar/<klasör adı>/ içine kopyalar
    void videoKopyala(Uri agac) {
        if (kopyalaniyor) return;
        kopyalaniyor = true;
        new Thread(() -> {
            long[] sayac = {0, 0, System.currentTimeMillis()};
            try {
                DocumentFile kokD = DocumentFile.fromTreeUri(this, agac);
                if (kokD == null || !kokD.isDirectory()) throw new Exception("Klasör okunamadı");
                String ad = kokD.getName() == null ? "Videolar" : guvenliAd(kokD.getName());
                File hedef = new File(new File(rehberKlasoru(), "videolar"), ad);
                videoAgaci(kokD, hedef, sayac, 0);
                if (sayac[0] == 0) throw new Exception("Bu klasörde video bulunamadı (mp4, webm, mkv, 3gp…).");
                js("window.videoBitti&&videoBitti(true," + jsMetin(sayac[0] + " video eklendi") + ")");
            } catch (Exception e) {
                js("window.videoBitti&&videoBitti(false," + jsMetin("Hata: " + e.getMessage()) + ")");
            } finally {
                kopyalaniyor = false;
            }
        }).start();
    }

    void videoAgaci(DocumentFile kaynak, File hedef, long[] sayac, int derinlik) throws Exception {
        if (derinlik > 4) return;
        for (DocumentFile c : kaynak.listFiles()) {
            String ad = c.getName();
            if (ad == null || ad.startsWith(".")) continue;
            if (c.isDirectory()) {
                // alt klasör kendi kategorisi olur
                videoAgaci(c, new File(hedef.getParentFile(), guvenliAd(ad)), sayac, derinlik + 1);
            } else if (videoMu(ad)) {
                hedef.mkdirs();
                File h = new File(hedef, guvenliAd(ad));
                if (h.exists() && h.length() == c.length()) { sayac[0]++; continue; }
                File gecici = new File(hedef, ".kopya_" + guvenliAd(ad));
                long once = sayac[0];
                dosyaKopyala(c, gecici, sayac);
                if (!gecici.renameTo(h)) throw new Exception("Kaydedilemedi: " + ad);
                if (sayac[0] == once) sayac[0]++;
                js("window.videoIlerleme&&videoIlerleme(" + sayac[0] + "," + sayac[1] + ")");
            }
        }
    }

    static String guvenliAd(String ad) {
        return ad.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    void klasorDegistir(DocumentFile kaynak, File hedef, long[] sayac) throws Exception {
        File gecici = new File(hedef.getParentFile(), ".yeni_" + hedef.getName());
        sil(gecici);
        klasorKopyala(kaynak, gecici, sayac);
        sil(hedef);
        if (!gecici.renameTo(hedef)) throw new Exception("Klasör yerleştirilemedi: " + hedef.getName());
    }

    void klasorKopyala(DocumentFile kaynak, File hedef, long[] sayac) throws Exception {
        hedef.mkdirs();
        for (DocumentFile c : kaynak.listFiles()) {
            String ad = c.getName();
            if (ad == null) continue;
            File h = new File(hedef, guvenliAd(ad));
            if (c.isDirectory()) klasorKopyala(c, h, sayac);
            else dosyaKopyala(c, h, sayac);
        }
    }

    void dosyaKopyala(DocumentFile kaynak, File hedef, long[] sayac) throws Exception {
        byte[] tampon = new byte[64 * 1024];
        try (InputStream i = getContentResolver().openInputStream(kaynak.getUri());
             OutputStream o = new FileOutputStream(hedef)) {
            if (i == null) throw new Exception("Okunamadı: " + kaynak.getName());
            int n;
            while ((n = i.read(tampon)) > 0) {
                o.write(tampon, 0, n);
                sayac[1] += n;
            }
        }
        sayac[0]++;
        long simdi = System.currentTimeMillis();
        if (simdi - sayac[2] > 400) {
            sayac[2] = simdi;
            js("window.icerikIlerleme&&icerikIlerleme(" + sayac[0] + "," + sayac[1] + ")");
        }
    }

    static void sil(File f) {
        if (!f.exists()) return;
        if (f.isDirectory()) {
            File[] l = f.listFiles();
            if (l != null) for (File c : l) sil(c);
        }
        f.delete();
    }

    static long[] boyut(File f) {
        if (f.isFile()) return new long[]{1, f.length()};
        long[] t = {0, 0};
        File[] l = f.listFiles();
        if (l != null) for (File c : l) {
            long[] b = boyut(c);
            t[0] += b[0];
            t[1] += b[1];
        }
        return t;
    }

    // ------------------------------------------------------------------
    // JavaScript köprüsü: sayfada window.Android olarak görünür
    // ------------------------------------------------------------------
    class Kopru {
        @JavascriptInterface
        public String surum() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "?";
            }
        }

        @JavascriptInterface
        public void icerikSec() {
            runOnUiThread(() -> {
                try {
                    startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_KLASOR);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Klasör seçici açılamadı", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public boolean kopyalaniyorMu() {
            return kopyalaniyor;
        }

        @JavascriptInterface
        public String icerikDurumu() {
            try {
                JSONObject j = new JSONObject();
                JSONArray a = new JSONArray();
                File[] l = rehberKlasoru().listFiles();
                if (l != null) for (File c : l) {
                    if (c.getName().startsWith(".")) continue;
                    long[] b = boyut(c);
                    a.put(new JSONObject().put("ad", c.getName()).put("dosya", b[0]).put("bayt", b[1]));
                }
                j.put("paketler", a);
                StatFs st = new StatFs(getFilesDir().getAbsolutePath());
                j.put("bos", st.getAvailableBytes());
                return j.toString();
            } catch (Exception e) {
                return "{\"paketler\":[],\"bos\":0}";
            }
        }

        @JavascriptInterface
        public String dosyaListe(String klasor) {
            JSONArray a = new JSONArray();
            try {
                if (klasor == null || klasor.contains("..")) return "[]";
                File k = new File(rehberKlasoru(), klasor);
                listele(k, "", a, 0);
            } catch (Exception ignored) { }
            return a.toString();
        }

        void listele(File k, String on, JSONArray a, int d) throws Exception {
            File[] l = k.listFiles();
            if (l == null || d > 5) return;
            for (File f : l) {
                if (f.getName().startsWith(".")) continue;
                if (f.isDirectory()) listele(f, on + f.getName() + "/", a, d + 1);
                else a.put(new JSONObject().put("yol", on + f.getName()).put("bayt", f.length()).put("zaman", f.lastModified()));
            }
        }

        @JavascriptInterface
        public void videoEkle() {
            runOnUiThread(() -> {
                try {
                    startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_VIDEO);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Klasör seçici açılamadı", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public boolean dosyaSil(String yol) {
            try {
                if (yol == null || yol.contains("..")) return false;
                File kokK = rehberKlasoru();
                File f = new File(kokK, yol);
                if (!f.getCanonicalPath().startsWith(kokK.getCanonicalPath()) || !f.isFile()) return false;
                boolean ok = f.delete();
                File ust = f.getParentFile();
                String[] kalan = ust != null ? ust.list() : null;
                if (ust != null && kalan != null && kalan.length == 0 && !ust.equals(kokK)) ust.delete();
                return ok;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean icerikSil(String ad) {
            if (ad == null || ad.contains("/") || ad.contains("..") || ad.isEmpty()) return false;
            sil(new File(rehberKlasoru(), ad));
            return true;
        }

        @JavascriptInterface
        public void dosyaKaydet(String ad, String icerik) {
            runOnUiThread(() -> {
                bekleyenIcerik = icerik;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, ad);
                try {
                    startActivityForResult(i, REQ_KAYDET);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Kaydetme penceresi açılamadı", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    // /rehber/... adreslerini uygulamanın içindeki içerik klasöründen sunar
    static class IcerikYolu implements WebViewAssetLoader.PathHandler {
        final File kok;
        final String kokYol;

        IcerikYolu(File kok) {
            this.kok = kok;
            String y;
            try { y = kok.getCanonicalPath(); } catch (Exception e) { y = kok.getAbsolutePath(); }
            this.kokYol = y;
        }

        @Override
        public WebResourceResponse handle(String yol) {
            try {
                File f = new File(kok, yol);
                String c = f.getCanonicalPath();
                if (!c.startsWith(kokYol) || !f.isFile()) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Yok", new java.util.HashMap<>(), null);
                }
                return new WebResourceResponse(tur(yol), "utf-8", new FileInputStream(f));
            } catch (Exception e) {
                return new WebResourceResponse("text/plain", "utf-8", 404, "Yok", new java.util.HashMap<>(), null);
            }
        }

        static String tur(String y) {
            y = y.toLowerCase();
            if (y.endsWith(".js") || y.endsWith(".mjs")) return "application/javascript";
            if (y.endsWith(".wasm")) return "application/wasm";
            if (y.endsWith(".json")) return "application/json";
            if (y.endsWith(".html") || y.endsWith(".htm")) return "text/html";
            if (y.endsWith(".css")) return "text/css";
            if (y.endsWith(".png")) return "image/png";
            if (y.endsWith(".jpg") || y.endsWith(".jpeg")) return "image/jpeg";
            if (y.endsWith(".webp")) return "image/webp";
            if (y.endsWith(".svg")) return "image/svg+xml";
            if (y.endsWith(".pdf")) return "application/pdf";
            if (y.endsWith(".mp3")) return "audio/mpeg";
            if (y.endsWith(".mp4") || y.endsWith(".m4v")) return "video/mp4";
            if (y.endsWith(".webm")) return "video/webm";
            if (y.endsWith(".mkv")) return "video/x-matroska";
            if (y.endsWith(".3gp")) return "video/3gpp";
            if (y.endsWith(".mov")) return "video/quicktime";
            if (y.endsWith(".ogv")) return "video/ogg";
            if (y.endsWith(".m4a")) return "audio/mp4";
            if (y.endsWith(".ogg")) return "audio/ogg";
            if (y.endsWith(".txt")) return "text/plain";
            return "application/octet-stream";
        }
    }
}
