#!/usr/bin/env python3
"""
Kiwix ZIM dosyasını (Wikipedia, WikiHow, iFixit, Gutenberg...) Çevrimdışı Rehberim'in
Kütüphane bölümünün okuyabildiği pakete çevirir.

Kullanım:
    python3 kutuphane_paket.py dosya.zim cikti/wikihow --ad wikihow [--resimler] [--en-fazla 50000]

Çıktı (her şey .js dosyası: bilgisayarda çift tıklayarak açınca da çalışsın diye):
    wikipedia/index.js     -> paket bilgisi
    wikipedia/i/XX.js      -> başlık dizini (başlığın ilk 2 harfine göre)
    wikipedia/c/N.js       -> sıkıştırılmış (gzip+base64) madde parçaları
İçerik: Wikipedia katkıcıları, CC BY-SA 4.0. ZIM: Kiwix / openZIM.
"""
import sys, os, json, gzip, base64, re, time, argparse, hashlib, posixpath
from html.parser import HTMLParser
from urllib.parse import unquote
from collections import defaultdict

# ---------- JS'teki sade() ile aynı sadeleştirme ----------
KIRIL = {"а":"a","б":"b","в":"v","г":"g","д":"d","е":"e","ё":"e","ж":"j","з":"z","и":"i","й":"y","к":"k","л":"l","м":"m",
         "н":"n","о":"o","п":"p","р":"r","с":"s","т":"t","у":"u","ф":"f","х":"h","ц":"s","ч":"c","ш":"s","щ":"s","ы":"i",
         "э":"e","ю":"yu","я":"ya","ь":"","ъ":""}
def sade(s):
    s = (s or "").replace("I", "ı").replace("İ", "i").lower()
    out = []
    for ch in s:
        if ch in "ıi": out.append("i")
        elif ch == "ş": out.append("s")
        elif ch == "ğ": out.append("g")
        elif ch == "ü": out.append("u")
        elif ch == "ö": out.append("o")
        elif ch == "ç": out.append("c")
        elif ch == "â": out.append("a")
        elif ch in KIRIL: out.append(KIRIL[ch])
        elif ("a" <= ch <= "z") or ("0" <= ch <= "9") or ch == " ": out.append(ch)
        else: out.append(" ")
    return re.sub(r"\s+", " ", "".join(out)).strip()

def anahtar(baslik):
    s = sade(baslik).replace(" ", "")
    return (s[:2] + "__")[:2] if s else "__"

# ---------- HTML temizleyici ----------
IZINLI = {"p","h1","h2","h3","h4","h5","h6","ul","ol","li","b","strong","i","em","a","table","thead","tbody","tr","td","th",
          "br","blockquote","dl","dt","dd","sub","sup","details","summary","section","caption","small","code","pre","hr","u","s"}
ATLA_ETIKET = {"script","style","link","meta","img","figure","picture","video","audio","noscript","svg","math","iframe",
               "map","object","button","input","form","head","title","source","track"}
RESIM_UZ = {"image/jpeg":".jpg","image/png":".png","image/webp":".webp","image/gif":".gif","image/svg+xml":".svg"}
def resim_adi(yol):
    """Resmin paket içindeki dosya adı: yolun özeti + (biliniyorsa) uzantısı."""
    uz = posixpath.splitext(yol)[1].lower()
    if uz not in (".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg"):
        uz = ""
    return hashlib.md5(yol.encode("utf-8")).hexdigest()[:16] + uz
ATLA_SINIF = ("reference","references","reflist","navbox","metadata","mw-editsection","noprint","mw-ref","ambox",
              "mbox","hatnote","thumb","gallery","mw-empty-elt","sistersitebox","printfooter","catlinks","toc")
BOS = {"br","hr","img","meta","link","input","source","track","wbr","col","area","base","embed","param"}

def esc(t):
    return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def yol_coz(href, taban=""):
    """ZIM içi bağlantıyı (maddenin bulunduğu yere göre) ZIM yoluna çevirir; dış bağlantı ise None."""
    if not href or href.startswith(("#", "http:", "https:", "//", "mailto:", "javascript:", "data:", "tel:")):
        return None
    h = unquote(href.split("#")[0].split("?")[0])
    if not h:
        return None
    if h.startswith("/"):
        h = h.lstrip("/")
    else:
        h = posixpath.normpath(posixpath.join(posixpath.dirname(taban), h))
    while h.startswith("../"):
        h = h[3:]
    if h in (".", ".."):
        return None
    if h.startswith("A/") or h.startswith("I/") or h.startswith("-/"):
        h = h[2:]
    return h or None

class Temizle(HTMLParser):
    def __init__(self, taban="", resimler=None):
        super().__init__(convert_charrefs=True)
        self.taban = taban
        self.resimler = resimler  # None = resim yok; set = yazılan resim adları
        self.o = []
        self.atla = 0
        self.govdede = False
        self.h1_atla = 0
    def handle_starttag(self, t, a):
        if t == "body":
            self.govdede = True
            return
        if self.atla:
            if t not in BOS:
                self.atla += 1
            return
        a = dict(a)
        if t == "img" and self.resimler is not None:
            y = yol_coz(a.get("src") or a.get("data-src"), self.taban)
            if y:
                self.o.append('<img data-r="%s" alt="">' % resim_adi(y))
            return
        sinif = (a.get("class") or "") + " " + (a.get("id") or "")
        if self.resimler is not None and t in ("figure", "picture"):
            return
        if t in ATLA_ETIKET or any(k in sinif.split() for k in ATLA_SINIF) or (a.get("style") or "").replace(" ", "").find("display:none") >= 0:
            if t not in BOS:
                self.atla = 1
            return
        if t == "h1":  # başlığı uygulama kendisi gösterir
            self.h1_atla = 1
            return
        if t not in IZINLI:
            return
        if t == "a":
            y = yol_coz(a.get("href"), self.taban)
            if y:
                self.o.append('<a data-w="%s">' % esc(y).replace('"', "&quot;"))
            else:
                self.o.append("<a>")
            return
        ek = ""
        if t in ("td", "th"):
            for k in ("colspan", "rowspan"):
                if a.get(k) and a[k].isdigit():
                    ek += ' %s="%s"' % (k, a[k])
        if t == "details" and "open" in a:
            ek = " open"
        self.o.append("<%s%s>" % (t, ek))
    def handle_endtag(self, t):
        if self.atla:
            if t not in BOS:
                self.atla -= 1
            return
        if t == "h1" and self.h1_atla:
            self.h1_atla = 0
            return
        if t in IZINLI and t not in BOS:
            self.o.append("</%s>" % t)
    def handle_data(self, d):
        if self.atla or self.h1_atla:
            return
        self.o.append(esc(d))
    def sonuc(self):
        h = "".join(self.o)
        h = re.sub(r"\s+", " ", h)
        h = re.sub(r"<(p|li|td|th|span|b|i|a|sup|section|div)>\s*</\1>", "", h)
        return h.strip()

def temizle(html, taban="", resimler=None):
    p = Temizle(taban, resimler)
    try:
        p.feed(html)
        p.close()
    except Exception:
        pass
    return p.sonuc()

# ---------- paket yazıcı ----------
class Paket:
    def __init__(self, cikti, ad="wikipedia", resimler=False):
        self.cikti = cikti
        self.ad = ad
        self.resimler = set() if resimler else None
        if resimler:
            os.makedirs(os.path.join(cikti, "r"), exist_ok=True)
        os.makedirs(os.path.join(cikti, "c"), exist_ok=True)
        os.makedirs(os.path.join(cikti, "i"), exist_ok=True)
        self.parca, self.parca_boy, self.parca_no = [], 0, 0
        self.dizin = defaultdict(list)
        self.madde = 0
        self.yonlendirme = 0
    def madde_ekle(self, yol, baslik, html):
        h = temizle(html, yol, self.resimler)
        if len(h) < 40:
            return
        self.parca.append([yol, baslik, h])
        self.parca_boy += len(h)
        self.dizin[anahtar(baslik)].append([baslik, yol, self.parca_no])
        if anahtar(yol.replace("_", " ")) != anahtar(baslik):
            self.dizin[anahtar(yol.replace("_", " "))].append([baslik, yol, self.parca_no])
        self.madde += 1
        if self.parca_boy >= 600_000:
            self.parca_yaz()
    def resim_ekle(self, yol, mime, veri):
        uz = RESIM_UZ.get(mime.split(";")[0].strip())
        if self.resimler is None or not uz or len(veri) > 600_000:
            return
        with open(os.path.join(self.cikti, "r", resim_adi(yol)), "wb") as f:
            f.write(veri)
        self.resim_sayi = getattr(self, "resim_sayi", 0) + 1
    def yonlendirme_ekle(self, yol, baslik, hedef):
        self.dizin[anahtar(baslik)].append([baslik, yol, -1, hedef])
        if anahtar(yol.replace("_", " ")) != anahtar(baslik):
            self.dizin[anahtar(yol.replace("_", " "))].append([baslik, yol, -1, hedef])
        self.yonlendirme += 1
    def parca_yaz(self):
        if not self.parca:
            return
        veri = gzip.compress(json.dumps(self.parca, ensure_ascii=False, separators=(",", ":")).encode("utf-8"), 9)
        with open(os.path.join(self.cikti, "c", "%d.js" % self.parca_no), "w") as f:
            f.write('WK("%s",%d,"%s");\n' % (self.ad, self.parca_no, base64.b64encode(veri).decode()))
        self.parca, self.parca_boy = [], 0
        self.parca_no += 1
    def bitir(self, bilgi):
        self.parca_yaz()
        # yönlendirmelerin hedef parçasını bul
        yol_parca = {}
        for l in self.dizin.values():
            for e in l:
                if e[2] >= 0:
                    yol_parca[e[1]] = e[2]
        anahtarlar = []
        for k, l in self.dizin.items():
            temiz = []
            for e in l:
                if e[2] == -1:
                    p = yol_parca.get(e[3])
                    if p is None:
                        continue
                    temiz.append([e[0], e[3], p, 1])  # 1 = yönlendirme
                else:
                    temiz.append(e)
            if not temiz:
                continue
            temiz.sort(key=lambda e: (len(e[0]), e[0]))
            with open(os.path.join(self.cikti, "i", k + ".js"), "w", encoding="utf-8") as f:
                f.write('WI("%s","%s",' % (self.ad, k))
                json.dump(temiz, f, ensure_ascii=False, separators=(",", ":"))
                f.write(");\n")
            anahtarlar.append(k)
        bilgi.update({"resim": self.resim_sayi if hasattr(self, "resim_sayi") else 0, "madde": self.madde, "yonlendirme": self.yonlendirme, "parca": self.parca_no,
                      "anahtarlar": sorted(anahtarlar), "olusturma": time.strftime("%Y-%m-%d"),
                      })
        bilgi["paket"] = self.ad
        bilgi["resimli"] = self.resimler is not None
        with open(os.path.join(self.cikti, "index.js"), "w", encoding="utf-8") as f:
            f.write('KI("%s",' % self.ad)
            json.dump(bilgi, f, ensure_ascii=False, separators=(",", ":"))
            f.write(");\n")
        print("Bitti: %d madde, %d yönlendirme, %d parça" % (self.madde, self.yonlendirme, self.parca_no))

# ---------- ZIM okuyucu (python-libzim) ----------
LISANS = {"wikipedia": "Wikipedia katkıcıları, CC BY-SA 4.0", "wikihow": "wikiHow katkıcıları, CC BY-NC-SA 3.0",
          "ifixit": "iFixit katkıcıları, CC BY-NC-SA 3.0", "gutenberg": "Project Gutenberg (kamu malı eserler)"}

def zim_maddeleri(yol, en_fazla=0, resimler=False):
    from libzim.reader import Archive
    z = Archive(yol)
    def meta(ad):
        try:
            return bytes(z.get_metadata(ad)).decode("utf-8", "replace")
        except Exception:
            return ""
    bilgi = {"ad": meta("Title") or "Wikipedia", "dil": meta("Language"), "tarih": meta("Date"),
             "aciklama": meta("Description"), "kaynak": os.path.basename(yol),
             "lisans": meta("License") or ""}
    try:
        ana = z.main_entry
        if ana.is_redirect:
            ana = ana.get_redirect_entry()
        bilgi["ana"] = ana.path
    except Exception:
        pass
    toplam = z.all_entry_count
    al = getattr(z, "_get_entry_by_id", None) or getattr(z, "get_entry_by_id")
    def uret():
        n = 0
        for i in range(toplam):
            try:
                e = al(i)
                if e.is_redirect:
                    h = e.get_redirect_entry()
                    yield ("y", e.path, e.title, h.path)
                    continue
                it = e.get_item()
                if it.mimetype.startswith("image/"):
                    if resimler:
                        yield ("r", e.path, it.mimetype, bytes(it.content))
                    continue
                if not it.mimetype.startswith("text/html"):
                    continue
                yield ("m", e.path, e.title, bytes(it.content).decode("utf-8", "replace"))
                n += 1
                if en_fazla and n >= en_fazla:
                    break
            except Exception as ex:
                print("  atlandı", i, ex)
            if i and i % 20000 == 0:
                print("  %d / %d öğe" % (i, toplam), flush=True)
    return bilgi, uret()

def ana():
    ap = argparse.ArgumentParser()
    ap.add_argument("zim"); ap.add_argument("cikti")
    ap.add_argument("--ad", default="", help="paket adı (wikipedia, wikihow, ifixit...)")
    ap.add_argument("--resimler", action="store_true", help="resimleri de pakete koy")
    ap.add_argument("--en-fazla", type=int, default=0, help="en fazla madde sayısı (0 = hepsi)")
    a = ap.parse_args()
    ad = re.sub(r"[^a-z0-9_-]", "", (a.ad or os.path.basename(a.cikti.rstrip("/"))).lower()) or "kutuphane"
    bilgi, akis = zim_maddeleri(a.zim, a.en_fazla, a.resimler)
    if not bilgi.get("lisans"):
        bilgi["lisans"] = LISANS.get(ad, "Kaynağın kendi lisansı")
    print("Paket:", ad, bilgi)
    p = Paket(a.cikti, ad, a.resimler)
    yonl = []
    for tur, yol, baslik, x in akis:
        if tur == "m":
            p.madde_ekle(yol, baslik or yol.replace("_", " "), x)
        elif tur == "r":
            p.resim_ekle(yol, baslik, x)
        else:
            yonl.append((yol, baslik, x))
    for yol, baslik, hedef in yonl:
        p.yonlendirme_ekle(yol, baslik or yol.replace("_", " "), hedef)
    p.bitir(bilgi)

if __name__ == "__main__":
    ana()
