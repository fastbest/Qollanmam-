#!/usr/bin/env python3
"""
Bilgisayarda / HDD'de 'videolar' klasörünün dizinini oluşturur.
Kullanım:  python3 video_dizin.py CevrimdisiRehber/videolar
Klasör yapısı: videolar/<Kategori>/<video>.mp4  (kategori klasörü isteğe bağlı)
"""
import os, sys, json
UZ = (".mp4", ".webm", ".m4v", ".mkv", ".3gp", ".mov", ".ogv")
kok = sys.argv[1] if len(sys.argv) > 1 else "videolar"
liste = []
for d, _, dosyalar in os.walk(kok):
    for f in dosyalar:
        if f.lower().endswith(UZ):
            yol = os.path.relpath(os.path.join(d, f), kok).replace(os.sep, "/")
            liste.append([yol, os.path.getsize(os.path.join(d, f))])
liste.sort()
with open(os.path.join(kok, "index.js"), "w", encoding="utf-8") as f:
    f.write("VIDEO_INDEX=")
    json.dump(liste, f, ensure_ascii=False)
    f.write(";\n")
print(len(liste), "video bulundu ->", os.path.join(kok, "index.js"))
