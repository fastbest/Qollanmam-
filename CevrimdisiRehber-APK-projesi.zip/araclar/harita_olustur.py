#!/usr/bin/env python3
"""
OpenStreetMap verisinden (osmium export ile üretilmiş GeoJSONSeq) Çevrimdışı Rehberim
uygulaması için internetsiz harita klasörü üretir.

Kullanım:
    python3 harita_olustur.py veri.geojsonseq cikti/harita

Çıktı:
    harita/index.js   -> hangi parçaların var olduğu
    harita/ara.js     -> köy, mahalle, eczane, hastane, cami... arama listesi
    harita/o/X_Y.js   -> genel görünüm (büyük yollar, büyük göller) - z7 ızgara
    harita/d/X_Y.js   -> ayrıntı (tüm yollar, kanallar, köyler, yerler) - z11 ızgara
Harita verisi © OpenStreetMap katkıcıları (ODbL).
"""
import sys, os, json, math, time
from collections import defaultdict

Z_O, Z_D = 7, 11
Q = 100000  # 1e-5 derece (~1 m)

ROAD = {"motorway":0,"motorway_link":0,"trunk":1,"trunk_link":1,"primary":2,"primary_link":2,
        "secondary":3,"secondary_link":3,"tertiary":4,"tertiary_link":4,
        "unclassified":5,"residential":5,"living_street":5,"road":5,
        "service":6,"track":7,
        "footway":8,"path":8,"pedestrian":8,"cycleway":8,"steps":8,"bridleway":8}
RAIL = {"rail","light_rail","subway","narrow_gauge","tram"}
WATERWAY = {"river":0,"canal":1,"stream":2,"drain":2,"ditch":2}
PLACE_O = {"city","town"}
PLACE_D = {"village","hamlet","suburb","neighbourhood","quarter","isolated_dwelling"}
POI = {"hospital":"h","clinic":"h","doctors":"h","pharmacy":"e","fuel":"f","police":"l",
       "drinking_water":"w","marketplace":"m"}

def tile(lon, lat, z):
    n = 2 ** z
    lat = max(-85.0, min(85.0, lat))
    x = int((lon + 180.0) / 360.0 * n)
    r = math.radians(lat)
    y = int((1.0 - math.log(math.tan(r) + 1.0 / math.cos(r)) / math.pi) / 2.0 * n)
    return max(0, min(n - 1, x)), max(0, min(n - 1, y))

def tile_origin(x, y, z):
    n = 2 ** z
    lon = x / n * 360.0 - 180.0
    lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
    return int(round(lon * Q)), int(round(lat * Q))

def simplify(pts, tol):
    """Douglas-Peucker (derece cinsinden tolerans), yinelemeli."""
    if len(pts) < 3 or tol <= 0:
        return pts
    keep = [False] * len(pts)
    keep[0] = keep[-1] = True
    stack = [(0, len(pts) - 1)]
    t2 = tol * tol
    while stack:
        a, b = stack.pop()
        ax, ay = pts[a]; bx, by = pts[b]
        dx, dy = bx - ax, by - ay
        L = dx * dx + dy * dy
        best, bi = -1.0, -1
        for i in range(a + 1, b):
            px, py = pts[i]
            if L == 0:
                d = (px - ax) ** 2 + (py - ay) ** 2
            else:
                t = ((px - ax) * dx + (py - ay) * dy) / L
                t = max(0.0, min(1.0, t))
                d = (px - ax - t * dx) ** 2 + (py - ay - t * dy) ** 2
            if d > best:
                best, bi = d, i
        if best > t2 and bi > 0:
            keep[bi] = True
            stack.append((a, bi)); stack.append((bi, b))
    return [p for p, k in zip(pts, keep) if k]

def enc(pts, o):
    """Noktaları parça başlangıcına göre fark (delta) kodlu tamsayılara çevirir."""
    out = []
    px, py = o
    for lon, lat in pts:
        ix, iy = int(round(lon * Q)), int(round(lat * Q))
        if out and ix == px and iy == py:
            continue
        out.append(ix - px); out.append(iy - py)
        px, py = ix, iy
    return out

class Katman:
    def __init__(self, z):
        self.z = z
        self.h = defaultdict(lambda: {"r": [], "w": [], "a": [], "n": [], "i": []})
    def line_split(self, key, cls, pts):
        """Çizgiyi geçtiği parçalara böler (sınır noktası iki parçaya da eklenir)."""
        if len(pts) < 2:
            return
        cur_t = tile(pts[0][0], pts[0][1], self.z)
        run = [pts[0]]
        for p in pts[1:]:
            t = tile(p[0], p[1], self.z)
            run.append(p)
            if t != cur_t:
                self._add_line(key, cls, cur_t, run)
                run = [run[-2], p]
                cur_t = t
        self._add_line(key, cls, cur_t, run)
    def _add_line(self, key, cls, t, run):
        if len(run) < 2:
            return
        o = tile_origin(t[0], t[1], self.z)
        e = enc(run, o)
        if len(e) >= 4:
            self.h[t][key].append([cls, e])
    def poly(self, rings):
        xs = [p[0] for p in rings[0]]; ys = [p[1] for p in rings[0]]
        t0 = tile(min(xs), max(ys), self.z); t1 = tile(max(xs), min(ys), self.z)
        cells = (t1[0] - t0[0] + 1) * (t1[1] - t0[1] + 1)
        if cells > 400:
            return
        for tx in range(t0[0], t1[0] + 1):
            for ty in range(t0[1], t1[1] + 1):
                o = tile_origin(tx, ty, self.z)
                er = [enc(r, o) for r in rings if len(r) >= 3]
                er = [r for r in er if len(r) >= 6]
                if er:
                    self.h[(tx, ty)]["a"].append(er)
    def point(self, key, item, lon, lat):
        self.h[tile(lon, lat, self.z)][key].append(item + [int(round(lon * Q)), int(round(lat * Q))])
    def yaz(self, klasor, ad):
        os.makedirs(os.path.join(klasor, ad), exist_ok=True)
        liste = []
        for (x, y), d in self.h.items():
            d = {k: v for k, v in d.items() if v}
            if not d:
                continue
            ox, oy = tile_origin(x, y, self.z)
            with open(os.path.join(klasor, ad, f"{x}_{y}.js"), "w", encoding="utf-8") as f:
                f.write(f'HY("{ad}",{x},{y},{ox},{oy},')
                json.dump(d, f, ensure_ascii=False, separators=(",", ":"))
                f.write(");\n")
            liste.append(f"{x}_{y}")
        return liste

def ad_bul(p):
    for k in ("name", "name:uz", "name:ru", "name:en", "int_name"):
        if p.get(k):
            return p[k]
    return ""

def merkez(geom):
    t = geom["type"]; c = geom["coordinates"]
    if t == "Point": return c
    if t == "Polygon": ring = c[0]
    elif t == "MultiPolygon": ring = c[0][0]
    elif t == "LineString": ring = c
    else: return None
    xs = [p[0] for p in ring]; ys = [p[1] for p in ring]
    return [(min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2]

def ana(girdi, cikti):
    O, D = Katman(Z_O), Katman(Z_D)
    ara = []
    bbox = [180, 90, -180, -90]
    sayi = defaultdict(int)
    t0 = time.time()
    with open(girdi, encoding="utf-8") as f:
        for no, satir in enumerate(f, 1):
            satir = satir.strip().lstrip("\x1e")
            if not satir:
                continue
            try:
                ft = json.loads(satir)
            except Exception:
                continue
            g = ft.get("geometry") or {}
            p = ft.get("properties") or {}
            gt = g.get("type"); c = g.get("coordinates")
            if not gt or c is None:
                continue
            hw = p.get("highway"); rw = p.get("railway"); ww = p.get("waterway")
            su_alani = (p.get("natural") == "water" or "water" in p or p.get("landuse") == "reservoir"
                        or ww == "riverbank")
            # --- yollar ---
            cizgiler = []
            if gt == "LineString": cizgiler = [c]
            elif gt == "MultiLineString": cizgiler = c
            elif gt == "Polygon" and (hw or rw) and not su_alani: cizgiler = [c[0]]
            if hw in ROAD and cizgiler and p.get("area") != "yes":
                cls = ROAD[hw]
                for ln in cizgiler:
                    D.line_split("r", cls, ln)
                    if cls <= 3:
                        O.line_split("r", cls, simplify(ln, 0.0008))
                sayi["yol"] += 1
            elif rw in RAIL and cizgiler:
                for ln in cizgiler:
                    D.line_split("r", 9, ln)
                    O.line_split("r", 9, simplify(ln, 0.0008))
                sayi["demiryolu"] += 1
            elif ww in WATERWAY and cizgiler:
                cls = WATERWAY[ww]
                for ln in cizgiler:
                    D.line_split("w", cls, ln)
                    if cls <= 1:
                        O.line_split("w", cls, simplify(ln, 0.001))
                sayi["akarsu"] += 1
            # --- su alanları ---
            if su_alani and gt in ("Polygon", "MultiPolygon", "LineString"):
                polys = [c] if gt == "Polygon" else c if gt == "MultiPolygon" else (
                    [[c]] if len(c) > 3 and c[0] == c[-1] else [])
                for rings in polys:
                    if not rings or len(rings[0]) < 4:
                        continue
                    xs = [q[0] for q in rings[0]]; ys = [q[1] for q in rings[0]]
                    span = max(max(xs) - min(xs), max(ys) - min(ys))
                    if span > 0.08:
                        O.poly([simplify(r, 0.0015) for r in rings])
                        if span < 1.0:
                            D.poly(rings)
                    elif span > 0.0004:
                        D.poly(rings)
                sayi["su"] += 1
            # --- yerleşim adları ---
            pl = p.get("place"); ad = ad_bul(p)
            if pl and ad and (pl in PLACE_O or pl in PLACE_D):
                m = merkez(g)
                if m:
                    if pl in PLACE_O:
                        O.point("n", [ad, pl], m[0], m[1])
                    D.point("n", [ad, pl], m[0], m[1])
                    ara.append([ad, pl, round(m[1], 5), round(m[0], 5)])
                    sayi["yerlesim"] += 1
            # --- önemli yerler ---
            am = p.get("amenity"); tur = POI.get(am)
            if am == "place_of_worship" and p.get("religion") == "muslim":
                tur = "c"
            if tur:
                m = merkez(g)
                if m:
                    D.point("i", [ad, tur], m[0], m[1])
                    if ad:
                        ara.append([ad, tur, round(m[1], 5), round(m[0], 5)])
                    sayi["onemli_yer"] += 1
            # sınırlar
            m = merkez(g)
            if m:
                bbox = [min(bbox[0], m[0]), min(bbox[1], m[1]), max(bbox[2], m[0]), max(bbox[3], m[1])]
            if no % 200000 == 0:
                print(f"  {no:,} öğe işlendi ({time.time()-t0:.0f} sn)", flush=True)

    os.makedirs(cikti, exist_ok=True)
    lo = O.yaz(cikti, "o"); ld = D.yaz(cikti, "d")
    with open(os.path.join(cikti, "index.js"), "w", encoding="utf-8") as f:
        f.write("HARITA_INDEX=")
        json.dump({"o": lo, "d": ld, "bbox": [round(v, 4) for v in bbox],
                   "tarih": time.strftime("%Y-%m-%d"), "sayi": sayi,
                   "kaynak": "© OpenStreetMap katkıcıları (ODbL)"}, f, ensure_ascii=False, separators=(",", ":"))
        f.write(";\n")
    with open(os.path.join(cikti, "ara.js"), "w", encoding="utf-8") as f:
        f.write("HARITA_ARA=")
        json.dump(ara, f, ensure_ascii=False, separators=(",", ":"))
        f.write(";\n")
    print("Bitti:", dict(sayi), f"genel parça {len(lo)}, ayrıntı parça {len(ld)}, aranabilir yer {len(ara)}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__); sys.exit(1)
    ana(sys.argv[1], sys.argv[2])
