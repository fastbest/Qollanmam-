# Çevrimdışı Rehberim – Android uygulaması

İnternetsiz çalışan kişisel rehber: **İlaçlar · Harita · İlk Yardım**. İleride Wikipedia, kitaplar ve Kur'an eklenecek.

## Yapı

```
app/src/main/assets/www/index.html   ← uygulamanın bütün ekranları (tek dosya)
app/src/main/assets/www/kuran/       ← Kur'an kitabı (fastbest/Quran2'den, internetsiz yazı tipleriyle)
app/src/main/java/.../MainActivity.java ← Android kabuğu (WebView, GPS, klasörden içerik yükleme)
araclar/harita_olustur.py            ← OpenStreetMap'ten harita klasörü üretir
.github/workflows/apk.yml            ← APK derler
.github/workflows/harita.yml         ← harita klasörü üretir
.github/workflows/kutuphane.yml      ← Wikipedia / WikiHow / iFixit paketi üretir
araclar/kutuphane_paket.py           ← Kiwix ZIM → uygulama paketi
```

APK küçük kalır. Büyük içerikler ayrı **paketler** hâlinde uygulamanın içine sonradan yüklenir:

| Paket klasörü | İçerik | Durum |
|---|---|---|
| `harita/` | Yollar, köyler, eczane, hastane, cami… | hazır |
| `wikipedia_tr/`, `wikipedia_uz/` | Wikipedia maddeleri | hazır |
| `wikihow_tr/` | WikiHow nasıl yapılır rehberleri (resimli) | hazır |
| `ifixit_tr/`, `ifixit_ru/` | iFixit tamir rehberleri (resimli) | hazır |
| `ceviri/` | İnternetsiz tercüme modeli (NLLB-200) | hazır |
| `videolar/` | Kendi videoların (klasör = kategori) | hazır |
| `kitaplar/` | PDF ve metinler | ileride |
| `kuran/` | Kur'an metni ve meal | ileride |

## APK derlemek (en son)

1. Bu klasördeki her şeyi bir GitHub deposuna yükle (`.github` klasörü dahil).
2. **Actions → APK derle → Run workflow**.
3. Bitince **Artifacts → CevrimdisiRehber-apk** indir, içindeki `app-debug.apk` dosyasını telefona kur (bilinmeyen kaynaklara izin vermen gerekir).

## Harita paketini üretmek ve yüklemek

1. **Actions → Harita oluştur → Run workflow** (bölge: `asia/uzbekistan`).
2. **CevrimdisiRehber** artifact'ını indir ve zip'i aç.
3. Klasörü telefona, hafıza kartına ya da USB/HDD'ye (OTG ile) koy.
4. Uygulamada **⋮ → İçerik paketleri → Klasörden yükle** de ve **CevrimdisiRehber** ya da **harita** klasörünü seç.
5. Dosyalar uygulamanın içine kopyalanır, bitince harita internetsiz çalışır. Kaynak klasörü sonra silebilirsin.

Aynı klasör bilgisayarda da çalışır: `cevrimdisi-rehberim.html` dosyasına çift tıklaman yeterli.

## Kütüphane paketleri (Wikipedia, WikiHow, iFixit)

1. **Actions → Kütüphane paketi oluştur → Run workflow**.
2. **zim** kutusuna tarihsiz Kiwix adını yaz:
   - `wikihow_tr_maxi` – WikiHow nasıl yapılır rehberleri (Türkçe) · Rusça: `wikihow_ru_maxi`
   - `ifixit_tr_all` – iFixit tamir rehberleri (Türkçe) · Rusça: `ifixit_ru_all` · en çok rehber: `ifixit_en_all`
   - `wikipedia_tr_all_mini` (küçük) / `wikipedia_tr_all_nopic` (tam) – Türkçe Wikipedia
   - `wikipedia_uz_all_nopic` – Özbekçe Wikipedia
   Tam ad yoksa iş aynı dildeki başka sürümü kendisi bulur; o dilde hiç yoksa durur ve mevcut dilleri listeler.
   Not: Türkçe ve Rusça iFixit'te rehberlerin hepsi çevrilmemiştir; çok aradığın bir rehber yoksa İngilizce paketi de ekleyebilirsin (ikisi yan yana durur).
3. **resimler**: WikiHow ve iFixit için işaretli bırak (tamir adımlarında resim şart). Wikipedia için kaldırabilirsin.
4. **en_fazla** ile sayfa sayısını sınırlayabilirsin (0 = hepsi). Paket çok büyük çıkarsa önce 5000 ile dene.
5. Bitince **…-paketi** artifact'ını indir, içindeki klasörü (ör. `wikihow_en`) uygulamaya yükle (**Menü → İçerik paketleri → Klasörden yükle**) ya da HDD'de HTML dosyasının yanına koy.

Arama başlığa göredir. Sayfa içindeki yeşil bağlantılar pakette olan diğer sayfaları açar.
WikiHow ve iFixit içerikleri CC BY-NC-SA lisanslıdır: kişisel kullanım serbest, ticari satış yapılamaz.

## Afet Rehberi

Uygulamanın içinde hazır gelir (paket gerekmez): deprem, sel, heyelan, yangın, gaz kaçağı, kış ve soba, aşırı sıcak, elektrik kesintisi, su temizleme, kimyasal/radyasyon, salgın, tahliye. Ayrıca işaretlenebilir afet çantası listesi ve aile acil planı.

## Videolarım

YouTube tarzı internetsiz video kütüphanesi: kapak resimleri, kategoriler, arama, kaldığın yerden devam, sıradaki video, hız ayarı, tam ekran.

- **Telefonda (APK):** Videolar → **＋ Video ekle** → video klasörünü seç (telefon, hafıza kartı, USB/HDD). Videolar uygulamanın içine kopyalanır; klasör adları kategori olur. Kopyalandıktan sonra asıl dosyaları silebilirsin.
- **Bilgisayarda / HDD'de:** Videoları `cevrimdisi-rehberim.html` dosyasının yanındaki `videolar/<Kategori>/` klasörlerine koy ve bir kez `python3 araclar/video_dizin.py videolar` çalıştır. Ya da Videolar bölümünde **＋ Video ekle** ile klasörü o an seç.

Desteklenen biçimler: mp4 (önerilir), webm, m4v, 3gp, mov; mkv telefona göre değişir.

## Kur'an

Kur'an bölümü, Telegram'daki Kur'an kitabının (fastbest/Quran2) aynısıdır ve APK'nın içinde gelir: sure/sayfa/cüz listesi, Arapça metin, mealler, kelime kelime anlam, Ezberlerim, Konular, Kitaplık, dualar.
- İnternetsiz çalışır; Arapça yazı tipleri (Amiri, Amiri Quran) uygulamanın içindedir.
- Kıraat sesleri, sesli meal ve dua sesleri internetten çalınır.
- Mikrofonla ayet arama: ses tanıma modeli ilk kullanımda internetten iner, sonra telefonda saklanır.
- Rehberim içinde Telegram istatistiği gönderilmez; varsayılan dil Türkçedir.
- Kur'an kitabını güncelledikten sonra `app/src/main/assets/www/kuran/index.html` dosyasını yeni sürümle değiştir (üstteki Telegram ve istatistik satırları ile Google Fonts satırı kaldırılmış hâlde).

## Tercüme

Özbekçe ⇄ Rusça / İngilizce / Arapça ve Türkçe ⇄ Rusça / İngilizce / Arapça; tamamen telefonda, internetsiz.
1. **Actions → Tercüme paketi oluştur → Run workflow** (model kutusuna dokunma).
2. **ceviri-paketi** artifact'ını indir, içindeki `ceviri` klasörünü **Menü → İçerik paketleri → Klasörden yükle** ile uygulamaya yükle.
3. Tercüme ekranında ilk çeviride model belleğe yüklenir (1–2 dakika), sonrakiler daha hızlıdır.
- Model: Meta NLLB-200 (distilled 600M, sıkıştırılmış), lisansı CC BY-NC 4.0: ticari kullanım yok.
- En az 3 GB RAM'li telefon önerilir; eski telefonlarda bellek yetmeyebilir.
- Bilgisayarda HTML dosyasına çift tıklayarak açınca tercüme çalışmaz (tarayıcı kısıtlaması); APK'da çalışır.

## Lisanslar

- Harita verisi © OpenStreetMap katkıcıları (ODbL)
- Wikipedia içeriği CC BY-SA. Kiwix okuyucu kütüphanesi eklenirse uygulamanın kaynak kodu da GPL olarak açık paylaşılmalıdır.

## Dil: Türkçe / Oʻzbekcha
Ana sayfanın üstündeki **TR | UZ** düğmesiyle tüm uygulama dili değişir (sayfa yeniden açılır, seçim hatırlanır).
Özbekçede menüler, 290 ilaç, 96 hastalık, ilk yardım, afet rehberi, harita yazıları ve Kur'an bölümünün dili birlikte değişir.
Wikipedia/WikiHow/iFixit paketleri kendi dilinde kalır (Özbekçe Wikipedia için `wikipedia_uz_all_nopic` paketi seçilebilir).
Çeviriler `index.html` içindeki `UZ_SOZ`, `UZ_IFADE`, `UZ_VERI` bölümlerinde durur.

## Hayatta Kalma, Tarım, Çevirici
- **Hayatta Kalma:** su bulma ve arıtma, ateş, barınak, soğuk/sıcak, yön bulma, işaret verme, düğümler, yiyecek, hijyen, elektriksiz günler (14 konu).
- **Tarım ve hayvancılık:** Özbekistan ekim takvimi, sebze-meyve, toprak-sulama, zararlılar, inek-koyun-tavuk bakımı, doğum, insana bulaşan hastalıklar, yem, kurutma, konserve, kışlık saklama (16 konu).
- **Çevirici:** so'm/dolar/euro/ruble/tenge/lira/yuan (kurlar elle güncellenir, telefonda kalır), uzunluk, ağırlık (pud, sentner), hacim, alan (sotix, hektar, dönüm), sıcaklık, hız.
Hepsi TR ve UZ dillerinde; içerikler `HK_TR/HK_UZ`, `TARIM_TR/TARIM_UZ` dizilerinde.
